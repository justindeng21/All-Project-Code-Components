
var events = JSON.parse(eventString)// use to access events

console.log(events[0].eventID)

var CU_Boulder_Bounds = {
north: 40.020,
south: 39.999,
west: -105.320,
east:  -105.210,
}

var event1 = '<div id="content">'+
'<div id="event1Notice">'+
'</div>'+
'<h1 id="firstHeading" class="firstHeading">Event1</h1>'+
'<div id="bodyContent">'+
'<p> Event 1 is ...</p>'+
'</div>'+
'</div>'
var university = {lat:40.007581,lng:-105.2659417}
var umc = {lat:40.0067275,lng:-105.2714839}
var engineering_center = {lat:40.0072036, lng:-105.2627826}
var norlin = {lat:40.008717, lng:-105.270784}
var farrand_field = {lat:40.0060463, lng:-105.2675692}
var rec_center = {lat:40.0102234,lng:-105.2693947}
var humanities = {lat:40.0092535,lng:-105.2717099}
var hellems = {lat:40.0076476,lng:-105.2727598}
var math = {lat:40.008222, lng:-105.265011}
var duane = {lat:40.007992, lng:-105.2674788}
var kobel = {lat:40.0060482, lng:-105.2656576}


var logo = {lat:40.009581,lng:-105.2659417}
var map;
  
function initMap(){
  
    map = new google.maps.Map(document.getElementById('map'),{
        zoom:10,
        center: university,
        disableDefaultUI:true,
        styles: [{"featureType":"all","elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#000000"},{"lightness":40}]},{"featureType":"all","elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#000000"},{"lightness":16}]},{"featureType":"all","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#000000"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":17},{"weight":1.2}]},{"featureType":"administrative.country","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"administrative.country","elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"administrative.province","elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"administrative.locality","elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"administrative.neighborhood","elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"administrative.land_parcel","elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":20}]},{"featureType":"landscape","elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"landscape.man_made","elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"landscape.natural","elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"landscape.natural.terrain","elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":21}]},{"featureType":"poi.park","elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"poi.school","elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"poi.school","elementType":"labels.text.stroke","stylers":[{"visibility":"simplified"}]},{"featureType":"poi.school","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#000000"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.highway","elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":18}]},{"featureType":"road.arterial","elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":16}]},{"featureType":"road.local","elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":19}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#230d00"},{"lightness":17},{"visibility":"off"}]},{"featureType":"water","elementType":"labels.text","stylers":[{"visibility":"off"}]}]
        })
    
    var LOGO = new google.maps.Marker({
        position: logo,
        map: map,
        title: 'uni_logo',
        icon: '/university_logo.png',
        });
  
    var UMC = new google.maps.Marker({
        position: umc,
        map : map,
        title : 'UMC',
        icon : '/umc.png',
        });
    
    var ENGINEERING_CENTER = new google.maps.Marker({
        position: engineering_center,
        map: map,
        title : 'ECCR',
        icon: '/eccr.png',
        });	
    
    var FARRAND_FIELD = new google.maps.Marker({
        position: farrand_field,
        map: map,
        title : 'FF',
        icon: '/farrand.png',
        });
  
    var NORLIN = new google.maps.Marker({
        position: norlin,
        map: map,
        title : 'FF',
        icon: '/norlin.png',
        });

    var REC = new google.maps.Marker({
        position: rec_center,
        map: map,
        title : 'FF',
        icon: '/rec.png',
        });

    var HUMANITIES = new google.maps.Marker({
        position: humanities,
        map: map,
        title : 'FF',
        icon: '/humanities.png',
        });

    var HELLEMS = new google.maps.Marker({
        position: hellems,
        map: map,
        title : 'FF',
        icon: '/hellems.png',
        });
    
    var MATH = new google.maps.Marker({
        position: math,
        map: map,
        title : 'FF',
        icon: '/math.png',
        });
    var DUANE = new google.maps.Marker({
        position: duane,
        map: map,
        title : 'FF',
        icon: '/duane.png',
        });

    google.maps.event.addListener(map, 'zoom_changed', function() {
  
        var zoom = map.getZoom();

        markerWidth = (zoom/9)*20
        markerHeight = (zoom/9)*20

        if(zoom == 14 && UMC.getVisible() == true)
        {
            UMC.setVisible(false)
            ENGINEERING_CENTER.setVisible(false)
            FARRAND_FIELD.setVisible(false)
            REC.setVisible(false)
            NORLIN.setVisible(false)
            MATH.setVisible(false)
            HELLEMS.setVisible(false)
            DUANE.setVisible(false)
            HUMANITIES.setVisible(false)
        }

        if(zoom == 15 && UMC.getVisible() == false)
        {
            UMC.setVisible(true)
            ENGINEERING_CENTER.setVisible(true)
            FARRAND_FIELD.setVisible(true)
            REC.setVisible(true)
            NORLIN.setVisible(true)
            MATH.setVisible(true)
            HELLEMS.setVisible(true)
            DUANE.setVisible(true)
            HUMANITIES.setVisible(true)
        }
  
        UMC.setIcon({
            url: '/umc.png',
            scaledSize: new google.maps.Size(markerWidth, markerHeight)
             });
        ENGINEERING_CENTER.setIcon({
      	    url: '/eccr.png',
      	    scaledSize: new google.maps.Size(markerWidth, markerHeight)
            });
        FARRAND_FIELD.setIcon({
            url: '/farrand.png',
            scaledSize: new google.maps.Size(markerWidth, markerHeight)
            });
        REC.setIcon({
            url: '/rec.png',
            scaledSize: new google.maps.Size(markerWidth, markerHeight)
            });
        NORLIN.setIcon({
            url: '/norlin.png',
            scaledSize: new google.maps.Size(markerWidth, markerHeight)
            });
        MATH.setIcon({
            url: '/math.png',
            scaledSize: new google.maps.Size(markerWidth, markerHeight)
            });
        HELLEMS.setIcon({
            url: '/hellems.png',
            scaledSize: new google.maps.Size(markerWidth, markerHeight)
            });
        DUANE.setIcon({
            url: '/duane.png',
            scaledSize: new google.maps.Size(markerWidth, markerHeight)
            });
        HUMANITIES.setIcon({
            url: '/humanities.png',
            scaledSize: new google.maps.Size(markerWidth, markerHeight)
            });
        });
    map.setZoom(16)
  }