function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
  }
  function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
  }

// Script for event cards

var event = '<%- query %';

//for (var i = 1; i < 7; i++){
  var card = document.createElement("div");
  card.className = "card";

  var text = '<div class="card">' +
                '<img src="https://via.placeholder.com/150C/O https://placeholder.com/" alt="Event Image" style="width:100%">' +
                '<div class="container">' +
                  '<h4>Event Name' +
                    '<p>Event Description' +
                '</div>' +
              '</div>';

  card.innerHTML = text;

  document.getElementById('cards').appendChild(card);
//}